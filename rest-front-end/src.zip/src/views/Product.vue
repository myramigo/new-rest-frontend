<template>
  <div>
    <h1>Product Page</h1>
    <p>{{ product }}</p>
  </div>
</template>

<script>
import { useECommerceStore } from "@/stores/e-commerce";
import { storeToRefs } from "pinia";
import qs from "qs";
import { useRoute, useRouter } from "vue-router";
export default {
  setup() {
    const eCommerceStore = useECommerceStore();
    const route = useRoute();
    eCommerceStore.fetchProduct(+route.params.id)
    const product = storeToRefs(eCommerceStore);
   return {
      product,
      // products,
      eCommerceStore
   }
   },
   name: "Product",
   }
    
</script>

<style scoped>
</style>